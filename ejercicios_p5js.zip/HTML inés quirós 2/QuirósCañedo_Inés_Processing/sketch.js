
function setup() {
  createCanvas(400, 400);  
}

function draw() {  background(220);       
  line(50, 50, 350, 50); 
  ellipse(200, 200, 100, 100);  }