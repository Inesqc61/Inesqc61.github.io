
function setup() {
  createCanvas(400, 400);  
}

function draw() {  background(225);  
                 stroke(255,0,0);
                 strokeWeight(3);
  line(100, 100, 300, 100); 
    stroke(0, 255, 0, 120);
  strokeWeight(6);        
  line(300, 100, 300, 300);  
                  stroke(0, 0, 255);   
  strokeWeight(2);       
  line(300, 300, 100, 300);
        stroke(120);           
  strokeWeight(4);       
  line(100, 300, 100, 100);          
 }
